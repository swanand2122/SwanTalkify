from flask import Flask, render_template
from flask_socketio import SocketIO

app = Flask(__name__)
socketio = SocketIO(app)

@app.route('/')
def index():
    return "Signaling Server Running"

@socketio.on('offer')
def handle_offer(data):
    print("Offer received:", data)
    socketio.emit('offer', data, broadcast=True)

@socketio.on('answer')
def handle_answer(data):
    print("Answer received:", data)
    socketio.emit('answer', data, broadcast=True)

@socketio.on('candidate')
def handle_candidate(data):
    print("Candidate received:", data)
    socketio.emit('candidate', data, broadcast=True)

if __name__ == '__main__':
    socketio.run(app, debug=True)
